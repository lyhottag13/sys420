export const updateSpecificationsAction = object => ({
    type: "updateSpecifications", 
    object
});