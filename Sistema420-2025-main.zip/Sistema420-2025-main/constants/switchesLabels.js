const switchesLabels = {
  0: "General",
  1: "Switch 1",
  2: "Switch 2",
  3: "Switch 3",
  4: "Switch 4",
};

export default switchesLabels;