import switchesLabels from './switchesLabels';
import testsViewParameters from './testsViewParameters';
import parametersSections from './parametersSections';

export {switchesLabels};
export {testsViewParameters};
export {parametersSections};
